package com.example.earthquakemonitor

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.LinearLayout
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.earthquakemonitor.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.eqRecycler.layoutManager = LinearLayoutManager(this)
        val eqList = mutableListOf<Earthquake>()
        eqList.add(Earthquake("1","Lugo", 4.3, 2345234L, -123213.23213, 28.23123))
        eqList.add(Earthquake("2","Chihuahua", 1.2, 2345234L, -123213.23213, 28.23123))
        eqList.add(Earthquake("3","Ontario", 6.0, 2345234L, -123213.23213, 28.23123))
        eqList.add(Earthquake("4","Lisboa", 4.6, 2345234L, -123213.23213, 28.23123))
        eqList.add(Earthquake("5","Pekín", 8.12, 2345234L, -123213.23213, 28.23123))
        eqList.add(Earthquake("6","Madrid", 2.9, 2345234L, -123213.23213, 28.23123))
        eqList.add(Earthquake("7","CDMX", 2.1, 2345234L, -123213.23213, 28.23123))

        val adapter = EqAdapter()
        binding.eqRecycler.adapter = adapter
        adapter.submitList(eqList)
    }
}